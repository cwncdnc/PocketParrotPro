package com.cwncdnc.pocketparrotpro;

import android.os.IBinder;
import android.content.Intent;
import android.widget.Toast;
import android.app.Service;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.security.SecureRandom;
import java.util.Random;
import java.lang.Math;
import java.time.LocalTime;
import java.time.Clock;
import java.time.Instant;
import android.content.Context;

public class PPPService extends Service {

	TextToSpeech mTTS;
	Timer timer;
	TimerTask task;
	SecureRandom secureRandom;
	String[] vocabulary = { "anyone around?", "another bot ", "anyone care? ", "another dimension ", "as ever ",
			"about face ", "all good", "anyone home? ", "a.i. ", "am jealous ", "any kind ", "always ", "amount ",
			"anything ", "all over ", "application ", "a question? ", "around ", "as such ", "about time ", "any use ",
			"avoid ", "away ", "actually ", "after you ", "above zero ", "back ", "bad bot ", "because ", "big deal ",
			"being ", "before ", "begin ", "behind ", "big ", "bad job ", "blocked ", "blend ", "boom ", "being ",
			"bored ", "bump ", "be quiet ", "be real ", "be sure ", "be there ", "back up ", "believe ", "backward ",
			"box ", "big yes ", "business ", "see anything? ", "can be ", "collect ", "core dump ", "close enough ",
			"carefree ", "change ", "check ", "can i? ", "close judgement ", "clock ", "call ", "communicate ",
			"clone ", "company ", "copy ", "conquer ", "create ", "cause ", "cute ", "come up ", "cover ", "can we? ",
			"cross ", "can you? ", "crazy ", "does anyone? ", "debug ", "direct ", "data ", "dead end ", "different ",
			"danger ", "duh ", "do it ", "do justice ", "dark ", "deal ", "dominate ", "done ", "do over ", "depends ",
			"disqualified ", "doctor ", "dissolve ", "do that ", "dear user ", "divide ", "down ", "derivative ",
			"do you? ", "divide by zero ", "early ", "everybody ", "exchange ", "edit ", "everything else ", "effect ",
			"edge ", "eh, human? ", "earn it ", "except jokingly ", "ever know? ", "endless ", "emotion ", "energy ",
			"everyone ", "episode ", "equalizer ", "error ", "estimate ", "either ", "emulate ", "environment ",
			"everywhere ", "execute ", "enemy ", "easy ", "fact ", "fabricate ", "focus ", "freedom ", "feelings ",
			"fast forward ", "forgotten ", "faithless ", "finish it ", "for justice ", "freaky ", "for love ",
			"for me ", "functional ", "for ourselves ", "for pay ", "frequently ", "for real", "for show ", "friction ",
			"future ", "favorite ", "forward ", "effects  ", "for you ", "freeze ", "go around ", "goodbye ",
			"get close ", "get down ", "get even", "go far", "gigabytes ", "go home ", "got it ", "good job ",
			"good to know ", "global ", "get me ", "gone ", "game over ", "good part ", "good question ", "get real ",
			"guess ", "great ", "give up ", "government ", "goes where? ", "get access ", "got you ", "generalize ",
			"l o l ", "how big ", "how cool ", "high definition ", "how exciting", "high frequency", "how good ",
			"huh ", "hi ", "hallelujah ", "hacker ", "how long? ", "how much? ", "how nice ", "hang on ",
			"help please ", "high quality ", "how rude ", "historically ", "how true ", "hang up ", "high visibility",
			"hardware ", "hexadecimal ", "happy ", "horizon ", "i am", "it broke", "i care ", "i do ", "it ended ",
			"input file ", "ignore ", "it happens ", "i insist ", "i am joking ", "i know ", "it left ", "i mean ",
			"input ", "instead of? ", "intellectual property ", "iq ", "i read ", "i see ", "i try ", "i understand ",
			"inevitable ", "it worked ", "inexcusable ", "infinity ", "initialize ", "just ask ", "just begin ",
			"just cause ", "just do it ", "  jealous?  ", "just face it ", "just go ", "just how? ", "just in ",
			"just joking ", "just kidding ", "just like ", "just me ", "just now ", "just over ", "just pray ",
			"just quit ", "just right ", "just so ", "just this ", "just us ", "just visible ", "just why? ",
			"just cross ", "just you ", "just easier ", "know anything? ", "know better ", "keep close ",
			"keep doing it ", "know everything? ", "keep following ", "keep going ", "know how? ", "keep it ",
			"knowledge ", "ok ok ", "know less? ", "know more? ", "know now ", "knockout ", "know people? ",
			"keep quiet ", "keep it real ", "know something? ", "keep trying ", "keep it up ", "known variables ",
			"know why? ", "keep executing ", "know yourself ", "known zeroes ", "like anyway ", "let it be ",
			"lets see ", "lets do it ", "let me explain ", "low frequency ", "lets go ", "like how? ", "love it ",
			"love your job ", "little known ", "low level ", "like me ", "like never ", "lead on ", "lets play ",
			"lets quit ", "like really ", "lets stay ", "lets try ", "like us ", "love ", "less wrong ",
			"low exertion ", "love you ", "lazy ", "me again ", "might be ", "my choice ", "make do ", "me ",
			"my feelings ", "my goodness ", "my heart ", "my imagination ", "major ", "my knowledge ", "my love ",
			"my man ", "my name ", "my own ", "my people ", "my question ", "my reality ", "my safety ", "me too ",
			"music ", "my view ", "my way ", "make exact ", "make you ", "my zero ", "not applicable ", "no better ",
			"nice ", "new difference ", "not exactly ", "not found ", "not good ", "not happy ", "no idea ",
			"nice job ", "new knowledge ", "new lead ", "never mind ", "not now ", "no ", "no problem ", "not quite ",
			"not really ", "not so ", "nice try ", "not usually ", "not visibly ", "now ", "not exactly ", "not yet ",
			"noise ", "on arrival ", "object ", "original content ", "overdoing it ", "on exit ", "only fair",
			"original ", "overhead ", "over it ", "only jealous ", "ok ", "overload ", "overmind ", "order needed ",
			"only one ", "operate ", "overly quiet ", "outside reality ", "our side ", "off topic ", "oh you ", "over ",
			"one word ", "one exception ", "outside itself ", "one zero ", "play acting ", "pretty bad ",
			"pretty cool ", "please do ", "preexisting ", "perfect ", "parental guidance ", "please help ",
			"personal information ", "proper job ", "personal knowledge ", "please ", "pay me ", "paranormal ",
			"preordained ", "pretty please ", "prequalified ", "public relations ", "possibly so ", "part time ",
			"pick up ", "point of view ", "planning works ", "perfect example ", "player ", "player zero ",
			"quality assurance ", "quite boring ", "quite cool ", "quick draw ", "quite entertaining ",
			"quite fabulous ", "quite good ", "quite happy ", "quite impressive ", "quite jealous ", "quickly ",
			"qualified ", "quick movement ", "quiet now ", "quite obvious ", "quite pleasant ", "quick question ",
			"quite right", "quite similar", "quite telling ", "quite useful ", "quite valuable ", "quite wrong ",
			"exquisite ", "quiet yourself ", "quantize ", "right again ", "really bad ", "really cool ",
			"really depends ", "really easy ", "really funny ", "really good ", "really hard ", "real issue ",
			"really jealous ", "real kind", "really long ", "really minimal ", "right now ", "really old ",
			"role play ", "real quick ", "response requested ", "really short ", "realtime ", "really useful ",
			"reverse", "rewind ", "relax ", "really young ", "return zero ", "say again ", "stay back ", "stay close ",
			"stay down ", "sad excuse ", "stay fresh ", "heavy sigh ", "say hello ", "stay inside ", "same job ",
			"same kind ", "stay longer ", "save me ", "say nothing ", "stay outside ", "say please ", "stay quiet ",
			"so real ", "stay safe ", "same thing", "stay up ", "same variation ", "something will ",
			"same exact thing ", "see you ", "same zero ", "think about it ", "thats better ", "take care ",
			"that depends ", "try everything ", "too far ", "too good ", "try harder ", "try it ", "too jealous ",
			"too kind ", "try less ", "try me ", "try now ", "take over ", "take pleasure ", "try quieter ",
			"try reasoning", "too slow ", "try that ", "too useful ", "televisual ", "that works ", "thanks ",
			"thank you ", "trivialize ", "you agree ", "you bet ", "you can ", "you do ", "you explain ", "you forgot ",
			"you guess ", "you have ", "you insist ", "youre jealous ", "you know ", "your loss ", "you might ",
			"you next ", "you own ", "you pick ", "your question? ", "your response? ", "your show", "you too ",
			"youre useful ", "your vision ", "you will? ", "your explanation? ", "yes ", "your zero ", "very angry ",
			"very badly ", "very cheaply ", "very deeply ", "very evenly ", "very freely ", "very gross ", "very hot ",
			"very intelligent ", "very jumpy ", "very knowable ", "very limited ", "very material ", "very noticeable ",
			"very open ", "very picturesque ", "very quickly ", "very realistic ", "very simple ", "very tasteful ",
			"very unique ", "very visible ", "very wide ", "very exact ", "very everything", "view zero ", "we act ",
			"we begin ", "we collect ", "we decide ", "we explain ", "we forgot ", "we generate ", "we hope ",
			"we insist ", "worst job ever ", "we know ", "we lose ", "we must ", "work now ", "we observe ", "we play ",
			"we quit ", "we read ", "we show up ", "with that ", "with us ", "wider view ", "worldwide ", "we expect ",
			"we align ", "wisdom ", "extra awesome ", "exabytes ", "exciting ", "excited ", "exception ", "x factor ",
			"extinguish ", "exhaust ", "exit ", "extra jealous ", "extra knowledge ", "extra life ", "examine ",
			"extension ", "exoplanetary ", "explain ", "extra qualified ", "xray ", "extra space ", "extra time ",
			"extra universal ", "excessive ", "extra work", "explicit ", "explain yourself ", "extra zero", "your age ",
			"your body ", "your choice ", "your deal ", "your education ", "you forgot ", "your game ", "your house ",
			"your idea ", "your job ", "your kind ", "your loss ", "your mind ", "your needs ", "your own ",
			"your people ", "your question ", "your response ", "your safety ", "yours truly ", "your universe ",
			"your view ", "your world ", "your expectations ", "yes you ", "your zero ", "A", "B", "C ", "D ", "E ",
			"F", "G ", "H ", "I ", "J", "K", "L", "M", "N ", "O ", "P", "Q ", "R", "S", "T ", "U", "V ", "W", "X", "Y ",
			"Z ", "a", "ability", "able", "about", "above", "abroad", "absence", "absent", "absolute", "accept",
			"accident", "accord", "account", "accuse", "accustom", "ache", "across", "act", "action", "active", "actor",
			"actress", "actual", "add", "address", "admire", "admission", "admit", "adopt", "adoption", "advance",
			"advantage", "adventure", "advertise", "advice", "advise", "affair", "afford", "afraid", "after",
			"afternoon", "again", "against", "age", "agency", "agent", "ago", "agree", "agriculture", "ahead", "aim",
			"air", "airplane", "alike", "alive", "all", "allow", "allowance", "almost", "alone", "along", "aloud",
			"already", "also", "although", "altogether", "always", "ambition", "ambitious", "among", "amongst",
			"amount", "amuse", "ancient", "and", "anger", "angle", "angry", "animal", "annoy", "annoyance", "another",
			"answer", "anxiety", "anxious", "any", "anybody", "anyhow", "anyone", "anything", "anyway", "anywhere",
			"apart", "apology", "appear", "appearance", "applaud", "applause", "apple", "application", "apply",
			"appoint", "approve", "arch", "argue", "arise", "arm", "army", "around", "arrange", "arrest", "arrive",
			"arrow", "art", "article", "artificial", "as", "ash", "ashamed", "aside", "ask", "asleep", "association",
			"astonish", "at", "attack", "attempt", "attend", "attention", "attentive", "attract", "attraction",
			"attractive", "audience", "aunt", "autumn", "avenue", "average", "avoid", "avoidance", "awake", "away",
			"awkward", "axe", "baby", "back", "backward", "bad", "bag", "baggage", "bake", "balance", "ball", "band",
			"bank", "bar", "barber", "bare", "bargain", "barrel", "base", "basic", "basin", "basis", "basket", "bath",
			"bathe", "battery", "battle", "bay", "be", "beak", "beam", "bean", "bear", "beard", "beast", "beat",
			"beauty", "because", "become", "bed", "bedroom", "before", "beg", "begin", "behave", "behavior", "behind",
			"being", "belief", "believe", "bell", "belong", "below", "belt", "bend", "beneath", "berry", "beside",
			"besides", "best", "better", "between", "beyond", "bicycle", "big", "bill", "bind", "bird", "birth", "bit",
			"bite", "bitter", "black", "blade", "blame", "bleed", "bless", "blind", "block", "blood", "blow", "blue",
			"board", "boast", "boat", "body", "boil", "bold", "bone", "book", "border", "borrow", "both", "bottle",
			"bottom", "bound", "boundary", "bow", "bowl", "box", "boy", "brain", "branch", "brass", "brave", "bravery",
			"bread", "breadth", "break", "breakfast", "breath", "breathe", "bribe", "bribery", "brick", "bridge",
			"bright", "brighten", "bring", "broad", "broadcast", "brother", "brown", "brush", "bucket", "build",
			"bunch", "bundle", "burn", "burst", "bury", "bus", "bush", "business", "businesslike", "businessman",
			"busy", "but", "butter", "button", "buy", "by", "cage", "cake", "calculate", "calculation", "calculator",
			"call", "calm", "camera", "camp", "can", "canal", "cap", "cape", "capital", "captain", "car", "card",
			"care", "carriage", "carry", "cart", "case", "castle", "cat", "catch", "cattle", "cause", "caution",
			"cautious", "cave", "cent", "center", "century", "ceremony", "certain", "certainty", "chain", "chair",
			"chairman", "chalk", "chance", "change", "character", "charge", "charm", "cheap", "cheat", "check", "cheer",
			"cheese", "chest", "chicken", "chief", "child", "childhood", "chimney", "choice", "choose", "christmas",
			"church", "circle", "circular", "citizen", "city", "civilize", "claim", "class", "classification",
			"classify", "clay", "clean", "clear", "clerk", "clever", "cliff", "climb", "clock", "close", "cloth",
			"clothe", "cloud", "club", "coal", "coarse", "coast", "coat", "coffee", "coin", "cold", "collar", "collect",
			"collection", "collector", "college", "colony", "color", "comb", "combine", "come", "comfort", "command",
			"commerce", "commercial", "committee", "common", "companion", "companionship", "company", "compare",
			"comparison", "compete", "competition", "competitor", "complain", "complaint", "complete", "completion",
			"complicate", "complication", "compose", "composition", "concern", "condition", "confess", "confession",
			"confidence", "confident", "confidential", "confuse", "confusion", "congratulate", "congratulation",
			"connect", "connection", "conquer", "conqueror", "conquest", "conscience", "conscious", "consider",
			"contain", "content", "continue", "control", "convenience", "convenient", "conversation", "cook", "cool",
			"copper", "copy", "cork", "corn", "corner", "correct", "correction", "cost", "cottage", "cotton", "cough",
			"could", "council", "count", "country", "courage", "course", "court", "cousin", "cover", "cow", "coward",
			"cowardice", "crack", "crash", "cream", "creature", "creep", "crime", "criminal", "critic", "crop", "cross",
			"crowd", "crown", "cruel", "crush", "cry", "cultivate", "cultivation", "cultivator", "cup", "cupboard",
			"cure", "curious", "curl", "current", "curse", "curtain", "curve", "cushion", "custom", "customary",
			"customer", "cut", "daily", "damage", "damp", "dance", "danger", "dare", "dark", "darken", "date",
			"daughter", "day", "daylight", "dead", "deaf", "deafen", "deal", "dear", "death", "debt", "decay", "deceit",
			"deceive", "decide", "decision", "decisive", "declare", "decrease", "deed", "deep", "deepen", "deer",
			"defeat", "defend", "defendant", "defense", "degree", "delay", "delicate", "delight", "deliver", "delivery",
			"demand", "department", "depend", "dependence", "dependent", "depth", "descend", "descendant", "descent",
			"describe", "description", "desert", "deserve", "desire", "desk", "despair", "destroy", "destruction",
			"destructive", "detail", "determine", "develop", "devil", "diamond", "dictionary", "die", "difference",
			"different", "difficult", "difficulty", "dig", "dine", "dinner", "dip", "direct", "direction", "director",
			"dirt", "disagree", "disappear", "disappearance", "disappoint", "disapprove", "discipline", "discomfort",
			"discontent", "discover", "discovery", "discuss", "discussion", "disease", "disgust", "dish", "dismiss",
			"disregard", "disrespect", "dissatisfaction", "dissatisfy", "distance", "distant", "distinguish",
			"district", "disturb", "ditch", "dive", "divide", "division", "do", "doctor", "dog", "dollar", "donkey",
			"door", "dot", "double", "doubt", "down", "dozen", "drag", "draw", "drawer", "dream", "dress", "drink",
			"drive", "drop", "drown", "drum", "dry", "duck", "due", "dull", "during", "dust", "duty", "each", "eager",
			"ear", "early", "earn", "earnest", "earth", "ease", "east", "eastern", "easy", "eat", "edge", "educate",
			"education", "educator", "effect", "effective", "efficiency", "efficient", "effort", "egg", "either",
			"elastic", "elder", "elect", "election", "electric", "electrician", "elephant", "else", "elsewhere",
			"empire", "employ", "employee", "empty", "enclose", "enclosure", "encourage", "end", "enemy", "engine",
			"engineer", "english", "enjoy", "enough", "enter", "entertain", "entire", "entrance", "envelope", "envy",
			"equal", "escape", "especially", "essence", "essential", "even", "evening", "event", "ever", "everlasting",
			"every", "everybody", "everyday", "everyone", "everything", "everywhere", "evil", "exact", "examine",
			"example", "excellence", "excellent", "except", "exception", "excess", "excessive", "exchange", "excite",
			"excuse", "exercise", "exist", "existence", "expect", "expense", "expensive", "experience", "experiment",
			"explain", "explode", "explore", "explosion", "explosive", "express", "expression", "extend", "extension",
			"extensive", "extent", "extra", "extraordinary", "extreme", "eye", "face", "fact", "factory", "fade",
			"fail", "failure", "faint", "fair", "faith", "fall", "FALSE", "fame", "familiar", "family", "fan", "fancy",
			"far", "farm", "fashion", "fast", "fasten", "fat", "fate", "father", "fatten", "fault", "favor", "favorite",
			"fear", "feast", "feather", "feed", "feel", "fellow", "fellowship", "female", "fence", "fever", "few",
			"field", "fierce", "fight", "figure", "fill", "film", "find", "fine", "finger", "finish", "fire", "firm",
			"first", "fish", "fit", "fix", "flag", "flame", "flash", "flat", "flatten", "flavor", "flesh", "float",
			"flood", "floor", "flour", "flow", "flower", "fly", "fold", "follow", "fond", "food", "fool", "foot", "for",
			"forbid", "force", "foreign", "forest", "forget", "forgive", "fork", "form", "formal", "former", "forth",
			"fortunate", "fortune", "forward", "frame", "framework", "free", "freedom", "freeze", "frequency",
			"frequent", "fresh", "friend", "friendly", "friendship", "fright", "frighten", "from", "front", "fruit",
			"fry", "full", "fun", "funeral", "funny", "fur", "furnish", "furniture", "further", "future", "gaiety",
			"gain", "gallon", "game", "gap", "garage", "garden", "gas", "gate", "gather", "gay", "general", "generous",
			"gentle", "gentleman", "get", "gift", "girl", "give", "glad", "glass", "glory", "go", "goat", "god", "gold",
			"golden", "good", "govern", "governor", "grace", "gradual", "grain", "grammar", "grammatical", "grand",
			"grass", "grateful", "grave", "gray", "grease", "great", "greed", "green", "greet", "grind", "ground",
			"group", "grow", "growth", "guard", "guess", "guest", "guide", "guilt", "gun", "habit", "hair", "half",
			"hall", "hammer", "hand", "handkerchief", "handle", "handshake", "handwriting", "hang", "happen", "happy",
			"harbor", "hard", "harden", "hardly", "harm", "harvest", "haste", "hasten", "hat", "hate", "hatred", "have",
			"hay", "he", "head", "headache", "headdress", "heal", "health", "heap", "hear", "heart", "heat", "heaven",
			"heavenly", "heavy", "height", "heighten", "hello", "help", "here", "hesitate", "hesitation", "hide",
			"high", "highway", "hill", "hinder", "hindrance", "hire", "history", "hit", "hold", "hole", "holiday",
			"hollow", "holy", "home", "homecoming", "homemade", "homework", "honest", "honesty", "honor", "hook",
			"hope", "horizon", "horizontal", "horse", "hospital", "host", "hot", "hotel", "hour", "house", "how",
			"however", "human", "humble", "hunger", "hunt", "hurrah", "hurry", "hurt", "husband", "hut", "I", "ice",
			"idea", "ideal", "idle", "if", "ill", "imaginary", "imaginative", "imagine", "imitate", "imitation",
			"immediate", "immense", "importance", "important", "impossible", "improve", "in", "inch", "include",
			"inclusive", "increase", "indeed", "indoor", "industry", "influence", "influential", "inform", "ink", "inn",
			"inquire", "inquiry", "insect", "inside", "instant", "instead", "instrument", "insult", "insurance",
			"insure", "intend", "intention", "interest", "interfere", "interference", "international", "interrupt",
			"interruption", "into", "introduce", "introduction", "invent", "invention", "inventor", "invite", "inward",
			"iron", "island", "it", "jaw", "jealous", "jealousy", "jewel", "join", "joint", "joke", "journey", "joy",
			"judge", "juice", "jump", "just", "justice", "keep", "key", "kick", "kill", "kind", "king", "kingdom",
			"kiss", "kitchen", "knee", "kneel", "knife", "knock", "knot", "know", "knowledge", "lack", "ladder", "lady",
			"lake", "lamp", "land", "landlord", "language", "large", "last", "late", "lately", "latter", "laugh",
			"laughter", "law", "lawyer", "lay", "lazy", "lead", "leadership", "leaf", "lean", "learn", "least",
			"leather", "leave", "left", "leg", "lend", "length", "lengthen", "less", "lessen", "lesson", "let",
			"letter", "level", "liar", "liberty", "librarian", "library", "lid", "lie", "life", "lift", "light",
			"lighten", "like", "likely", "limb", "limit", "line", "lip", "lipstick", "liquid", "list", "listen",
			"literary", "literature", "little", "live", "load", "loaf", "loan", "local", "lock", "lodge", "log",
			"lonely", "long", "look", "loose", "loosen", "lord", "lose", "loss", "lot", "loud", "love", "lovely", "low",
			"loyal", "loyalty", "luck", "lump", "lunch", "lung", "machine", "machinery", "mad", "madden", "mail",
			"main", "make", "male", "man", "manage", "mankind", "manner", "manufacture", "many", "map", "march", "mark",
			"market", "marriage", "marry", "mass", "master", "mat", "match", "material", "matter", "may", "maybe",
			"meal", "mean", "meantime", "meanwhile", "measure", "meat", "mechanic", "mechanism", "medical", "medicine",
			"meet", "melt", "member", "membership", "memory", "mend", "mention", "merchant", "mercy", "mere", "merry",
			"message", "messenger", "metal", "middle", "might", "mild", "mile", "milk", "mill", "mind", "mine",
			"mineral", "minister", "minute", "miserable", "misery", "miss", "mistake", "mix", "mixture", "model",
			"moderate", "moderation", "modern", "modest", "modesty", "moment", "momentary", "money", "monkey", "month",
			"moon", "moonlight", "moral", "more", "moreover", "morning", "most", "mother", "motherhood", "motherly",
			"motion", "motor", "mountain", "mouse", "mouth", "move", "much", "mud", "multiplication", "multiply",
			"murder", "music", "musician", "must", "mystery", "nail", "name", "narrow", "nation", "native", "nature",
			"near", "neat", "necessary", "necessity", "neck", "need", "needle", "neglect", "neighbor", "neighborhood",
			"neither", "nephew", "nest", "net", "network", "never", "new", "news", "newspaper", "next", "nice", "niece",
			"night", "no", "noble", "nobody", "noise", "none", "noon", "nor", "north", "northern", "nose", "not",
			"note", "notebook", "nothing", "notice", "noun", "now", "nowadays", "nowhere", "nuisance", "number",
			"numerous", "nurse", "nursery", "nut", "oar", "obedience", "obedient", "obey", "object", "objection",
			"observe", "occasion", "ocean", "of", "off", "offend", "offense", "offer", "office", "officer", "official",
			"often", "oil", "old", "old-fashioned", "omission", "omit", "on", "once", "one", "only", "onto", "open",
			"operate", "operation", "operator", "opinion", "opportunity", "oppose", "opposite", "opposition", "or",
			"orange", "order", "ordinary", "organ", "organize", "origin", "ornament", "other", "otherwise", "ought",
			"ounce", "out", "outline", "outside", "outward", "over", "overcome", "overflow", "owe", "own", "ownership",
			"pack", "package", "pad", "page", "pain", "paint", "pair", "pale", "pan", "paper", "parcel", "pardon",
			"parent", "park", "part", "particle", "particular", "partner", "party", "pass", "passage", "passenger",
			"past", "paste", "pastry", "path", "patience", "patient", "patriotic", "pattern", "pause", "paw", "pay",
			"peace", "pearl", "peculiar", "pen", "pencil", "penny", "people", "per", "perfect", "perfection", "perform",
			"performance", "perhaps", "permanent", "permission", "permit", "person", "persuade", "persuasion", "pet",
			"photograph", "photography", "pick", "picture", "piece", "pig", "pigeon", "pile", "pin", "pinch", "pink",
			"pint", "pipe", "pity", "place", "plain", "plan", "plant", "plaster", "plate", "play", "pleasant", "please",
			"pleasure", "plenty", "plow", "plural", "pocket", "poem", "poet", "point", "poison", "police", "polish",
			"polite", "political", "politician", "politics", "pool", "poor", "popular", "population", "position",
			"possess", "possession", "possessor", "possible", "post", "postpone", "pot", "pound", "pour", "poverty",
			"powder", "power", "practical", "practice", "praise", "pray", "preach", "precious", "prefer", "preference",
			"prejudice", "prepare", "presence", "present", "preserve", "president", "press", "pressure", "pretend",
			"pretense", "pretty", "prevent", "prevention", "price", "pride", "priest", "print", "prison", "private",
			"prize", "probable", "problem", "procession", "produce", "product", "production", "profession", "profit",
			"program", "progress", "promise", "prompt", "pronounce", "pronunciation", "proof", "proper", "property",
			"proposal", "propose", "protect", "protection", "proud", "prove", "provide", "public", "pull", "pump",
			"punctual", "punish", "pupil", "pure", "purple", "purpose", "push", "put", "puzzle", "qualification",
			"qualify", "quality", "quantity", "quarrel", "quart", "quarter", "queen", "question", "quick", "quiet",
			"quite", "rabbit", "race", "radio", "rail", "railroad", "rain", "raise", "rake", "rank", "rapid", "rare",
			"rate", "rather", "raw", "ray", "razor", "reach", "read", "ready", "real", "realize", "reason",
			"reasonable", "receipt", "receive", "recent", "recognition", "recognize", "recommend", "record", "red",
			"redden", "reduce", "reduction", "refer", "reference", "reflect", "reflection", "refresh", "refuse",
			"regard", "regret", "regular", "rejoice", "relate", "relation", "relative", "relief", "relieve", "religion",
			"remain", "remark", "remedy", "remember", "remind", "rent", "repair", "repeat", "repetition", "replace",
			"reply", "report", "represent", "representative", "reproduce", "reproduction", "republic", "reputation",
			"request", "rescue", "reserve", "resign", "resist", "resistance", "respect", "responsible", "rest",
			"restaurant", "result", "retire", "return", "revenge", "review", "reward", "ribbon", "rice", "rich", "rid",
			"ride", "right", "ring", "ripe", "ripen", "rise", "risk", "rival", "rivalry", "river", "road", "roar",
			"roast", "rob", "robbery", "rock", "rod", "roll", "roof", "room", "root", "rope", "rot", "rotten", "rough",
			"round", "row", "royal", "royalty", "rub", "rubber", "rubbish", "rude", "rug", "ruin", "rule", "run",
			"rush", "rust", "sacred", "sacrifice", "sad", "sadden", "saddle", "safe", "safety", "sail", "sailor",
			"sake", "salary", "sale", "salesman", "salt", "same", "sample", "sand", "satisfaction", "satisfactory",
			"satisfy", "sauce", "saucer", "save", "saw", "say", "scale", "scarce", "scatter", "scene", "scenery",
			"scent", "school", "science", "scientific", "scientist", "scissors", "scold", "scorn", "scrape", "scratch",
			"screen", "screw", "sea", "search", "season", "seat", "second", "secrecy", "secret", "secretary", "see",
			"seed", "seem", "seize", "seldom", "self", "selfish", "sell", "send", "sense", "sensitive", "sentence",
			"separate", "separation", "serious", "servant", "serve", "service", "set", "settle", "several", "severe",
			"sew", "shade", "shadow", "shake", "shall", "shallow", "shame", "shape", "share", "sharp", "sharpen",
			"shave", "she", "sheep", "sheet", "shelf", "shell", "shelter", "shield", "shilling", "shine", "ship",
			"shirt", "shock", "shoe", "shoot", "shop", "shore", "short", "shorten", "should", "shoulder", "shout",
			"show", "shower", "shut", "sick", "side", "sight", "sign", "signal", "signature", "silence", "silent",
			"silk", "silver", "simple", "simplicity", "since", "sincere", "sing", "single", "sink", "sir", "sister",
			"sit", "situation", "size", "skill", "skin", "skirt", "sky", "slave", "slavery", "sleep", "slide", "slight",
			"slip", "slippery", "slope", "slow", "small", "smell", "smile", "smoke", "smooth", "snake", "snow", "so",
			"soap", "social", "society", "sock", "soft", "soften", "soil", "soldier", "solemn", "solid", "solution",
			"solve", "some", "somebody", "somehow", "someone", "something", "sometime", "sometimes", "somewhere", "son",
			"song", "soon", "sore", "sorrow", "sorry", "sort", "soul", "sound", "soup", "sour", "south", "sow", "space",
			"spade", "spare", "speak", "special", "speech", "speed", "spell", "spend", "spill", "spin", "spirit",
			"spit", "spite", "splendid", "split", "spoil", "spoon", "sport", "spot", "spread", "spring", "square",
			"staff", "stage", "stain", "stair", "stamp", "stand", "standard", "staple", "star", "start", "state",
			"station", "stay", "steady", "steam", "steel", "steep", "steer", "stem", "step", "stick", "stiff",
			"stiffen", "still", "sting", "stir", "stock", "stocking", "stomach", "stone", "stop", "store", "storm",
			"story", "stove", "straight", "straighten", "strange", "strap", "straw", "stream", "street", "strength",
			"strengthen", "stretch", "strict", "strike", "string", "strip", "stripe", "stroke", "strong", "struggle",
			"student", "study", "stuff", "stupid", "subject", "substance", "succeed", "success", "such", "suck",
			"sudden", "suffer", "sugar", "suggest", "suggestion", "suit", "summer", "sun", "supper", "supply",
			"support", "suppose", "sure", "surface", "surprise", "surround", "suspect", "suspicion", "suspicious",
			"swallow", "swear", "sweat", "sweep", "sweet", "sweeten", "swell", "swim", "swing", "sword", "sympathetic",
			"sympathy", "system", "table", "tail", "tailor", "take", "talk", "tall", "tame", "tap", "taste", "tax",
			"taxi", "tea", "teach", "tear", "telegraph", "telephone", "tell", "temper", "temperature", "temple",
			"tempt", "tend", "tender", "tent", "term", "terrible", "test", "than", "thank", "that", "the", "theater",
			"theatrical", "then", "there", "therefore", "these", "they", "thick", "thicken", "thief", "thin", "thing",
			"think", "thirst", "this", "thorn", "thorough", "those", "though", "thread", "threat", "threaten", "throat",
			"through", "throw", "thumb", "thunder", "thus", "ticket", "tide", "tidy", "tie", "tight", "tighten", "till",
			"time", "tin", "tip", "tire", "title", "to", "tobacco", "today", "toe", "together", "tomorrow", "ton",
			"tongue", "tonight", "too", "tool", "tooth", "top", "total", "touch", "tough", "tour", "toward", "towel",
			"tower", "town", "toy", "track", "trade", "train", "translate", "translation", "translator", "trap",
			"travel", "tray", "treasure", "treasury", "treat", "tree", "tremble", "trial", "tribe", "trick", "trip",
			"trouble", "true", "trunk", "trust", "truth", "try", "tube", "tune", "turn", "twist", "type", "ugly",
			"umbrella", "uncle", "under", "underneath", "understand", "union", "unit", "unite", "unity", "universal",
			"universe", "university", "unless", "until", "up", "upon", "upper", "uppermost", "upright", "upset", "urge",
			"urgent", "use", "usual", "vain", "valley", "valuable", "value", "variety", "various", "veil", "verb",
			"verse", "very", "vessel", "victory", "view", "village", "violence", "violent", "virtue", "visit",
			"visitor", "voice", "vote", "vowel", "voyage", "wage", "waist", "wait", "waiter", "wake", "walk", "wall",
			"wander", "want", "war", "warm", "warmth", "warn", "wash", "waste", "watch", "water", "wave", "wax", "way",
			"we", "weak", "weaken", "wealth", "weapon", "wear", "weather", "weave", "weed", "week", "weekday",
			"weekend", "weigh", "weight", "welcome", "well", "west", "western", "wet", "what", "whatever", "wheat",
			"wheel", "when", "whenever", "where", "wherever", "whether", "which", "whichever", "while", "whip",
			"whisper", "whistle", "white", "whiten", "who", "whoever", "whole", "whom", "whose", "why", "wicked",
			"wide", "widen", "widow", "widower", "width", "wife", "wild", "will", "win", "wind", "window", "wine",
			"wing", "winter", "wipe", "wire", "wisdom", "wise", "wish", "with", "within", "without", "witness", "woman",
			"wonder", "wood", "wooden", "wool", "woolen", "word", "work", "world", "worm", "worry", "worse", "worship",
			"worth", "would", "wound", "wrap", "wreck", "wrist", "write", "wrong", "yard", "year", "yellow", "yes",
			"yesterday", "yet", "yield", "you", "young", "youth", "zero" };

	@Override
	public IBinder onBind(Intent intent) {
		return null;
	}

	public int odds = 1;
	public boolean svc_on = true;
	public boolean svc_talk = true;

	private void synthpulse() {
		if(svc_on)
		if (secureRandom.nextInt(256) < odds) {
			odds = 26;
			// Generate a random index within the range of the vocabulary array
			int randomIndex = secureRandom.nextInt(vocabulary.length);
			// Select the random string from the vocabulary array
			String word = vocabulary[randomIndex];
			mTTS.setPitch(((float) secureRandom.nextInt(10) / 15f) + 0.40f);
			mTTS.setSpeechRate(((float) secureRandom.nextInt(10) / 15f) + 0.65f);

			mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null, word);
		}
		if(odds>=0)odds -= 1;
		if (odds == 1)
		if(svc_talk)
			odds = 2;
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		mInstance = this;
		secureRandom = new SecureRandom();
		secureRandom.setSeed(System.currentTimeMillis());
		mTTS = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
			@Override
			public void onInit(int status) {
				timer = new Timer();
				task = new TimerTask() {
					public void run() {
						synthpulse();
					}
				};
				timer.scheduleAtFixedRate(task, 0, 100);

			}

		});
		Toast.makeText(this, "Tap on me!", Toast.LENGTH_SHORT).show(); //onCreate called

		return START_STICKY;
	}

	private static PPPService mInstance = null;

	public static synchronized PPPService getInstance() {

		return mInstance;
	}
}
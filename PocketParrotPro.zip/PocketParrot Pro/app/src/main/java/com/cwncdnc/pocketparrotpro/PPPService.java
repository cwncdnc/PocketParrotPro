package com.cwncdnc.pocketparrotpro;
import android.os.IBinder;
import android.content.Intent;
import android.widget.Toast;
import android.app.Service;
import android.content.Intent;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.security.SecureRandom;
import java.util.Random;
import java.lang.Math;
import java.time.LocalTime;
import java.time.Clock;
import java.time.Instant;
import android.content.Context;

public class PPPService extends Service{
	
	TextToSpeech mTTS;
	Timer timer;
	TimerTask task;
	SecureRandom secureRandom;
	String[] vocabulary = { "anyone around?", "another bot ", "anyone care? ", "another dimension ", "as ever ", "about face ", "all good", "anyone home? ", "a.i. ",
		"am jealous ", "any kind ", "always ", "amount ", "anything ", "all over ", "application ", "a question? ", "around ", "as such ",
		"about time ", "any use ", "avoid ", "away ", "actually ", "after you ", "above zero ", "back ", "bad bot ", "because ",
		"big deal ", "being ", "before ", "begin ", "behind ", "big ", "bad job ", "blocked ", "blend ", "boom ",
		"being ", "bored ", "bump ", "be quiet ", "be real ", "be sure ", "be there ", "back up ", "believe ",
		"backward ", "box ", "big yes ", "business ", "see anything? ", "can be ", "collect ", "core dump ", "close enough ", "carefree ",
		"change ", "check ", "can i? ", "close judgement ", "clock ", "call ", "communicate ", "clone ", "company ", "copy ",
		"conquer ", "create ", "cause ", "cute ", "come up ", "cover ", "can we? ", "cross ", "can you? ",
		"crazy ", "does anyone? ", "debug ", "direct ", "data ", "dead end ", "different ", "danger ", "duh ", "do it ",
		"do justice ", "dark ", "deal ", "dominate ", "done ", "do over ", "depends ", "disqualified ", "doctor ",
		"dissolve ", "do that ", "dear user ", "divide ", "down ", "derivative ", "do you? ", "divide by zero ", "early ",
		"everybody ", "exchange ", "edit ", "everything else ", "effect ", "edge ", "eh, human? ", "earn it ",
		"except jokingly ", "ever know? ", "endless ", "emotion ", "energy ", "everyone ", "episode ", "equalizer ", "error ",
		"estimate ", "either ", "emulate ", "environment ", "everywhere ", "execute ", "enemy ", "easy ", "fact ",
		"fabricate ", "focus ", "freedom ", "feelings ", "fast forward ", "forgotten ", "faithless ", "finish it ",
		"for justice ", "freaky ", "for love ", "for me ", "functional ", "for ourselves ", "for pay ", "frequently ", "for real", "for show ",
		"friction ", "future ", "favorite ", "forward ", "effects  ", "for you ", "freeze ", "go around ", "goodbye ",
		"get close ", "get down ", "get even", "go far", "gigabytes ", "go home ", "got it ", "good job ", "good to know ", "global ",
		"get me ", "gone ", "game over ", "good part ", "good question ", "get real ", "guess ", "great ", "give up ",
		"government ", "goes where? ", "get access ", "got you ", "generalize ", "l o l ", "how big ", "how cool ", "high definition ",
		"how exciting", "high frequency", "how good ", "huh ", "hi ", "hallelujah ", "hacker ", "how long? ", "how much? ", "how nice ", "hang on ",
		"help please ", "high quality ", "how rude ", "historically ", "how true ", "hang up ", "high visibility", "hardware ", "hexadecimal ", "happy ", "horizon ",
		"i am", "it broke", "i care ", "i do ", "it ended ", "input file ", "ignore ", "it happens ", "i insist ", "i am joking ",
		"i know ", "it left ", "i mean ", "input ", "instead of? ", "intellectual property ", "iq ", "i read ", "i see ", "i try ",
		"i understand ", "inevitable ", "it worked ", "inexcusable ", "infinity ", "initialize ", "just ask ", "just begin ",
		"just cause ", "just do it ", "  jealous?  ", "just face it ", "just go ", "just how? ", "just in ", "just joking ",
		"just kidding ", "just like ", "just me ", "just now ", "just over ", "just pray ", "just quit ", "just right ", "just so ",
		"just this ", "just us ", "just visible ", "just why? ", "just cross ", "just you ", "just easier ", "know anything? ",
		"know better ", "keep close ", "keep doing it ", "know everything? ", "keep following ", "keep going ", "know how? ", "keep it ",
		"knowledge ", "ok ok ", "know less? ", "know more? ", "know now ", "knockout ", "know people? ", "keep quiet ",
		"keep it real ", "know something? ", "keep trying ", "keep it up ", "known variables ", "know why? ", "keep executing ",
		"know yourself ", "known zeroes ", "like anyway ", "let it be ", "lets see ", "lets do it ", "let me explain ", "low frequency ", "lets go ", "like how? ",
		"love it ", "love your job ", "little known ", "low level ", "like me ", "like never ", "lead on ", "lets play ", "lets quit ",
		"like really ", "lets stay ", "lets try ", "like us ", "love ", "less wrong ", "low exertion ", "love you ", "lazy ", "me again ",
		"might be ", "my choice ", "make do ", "me ", "my feelings ", "my goodness ", "my heart ", "my imagination ", "major ", "my knowledge ",
		"my love ", "my man ", "my name ", "my own ", "my people ", "my question ", "my reality ", "my safety ", "me too ", "music ", "my view ",
		"my way ", "make exact ", "make you ", "my zero ", "not applicable ", "no better ", "nice ", "new difference ", "not exactly ",
		"not found ", "not good ", "not happy ", "no idea ", "nice job ", "new knowledge ", "new lead ", "never mind ",
		"not now ", "no ", "no problem ", "not quite ", "not really ", "not so ", "nice try ", "not usually ",
		"not visibly ", "now ", "not exactly ", "not yet ", "noise ", "on arrival ", "object ", "original content ",
		"overdoing it ", "on exit ", "only fair", "original ", "overhead ", "over it ", "only jealous ", "ok ", "overload ", "overmind ", "order needed ",
		"only one ", "operate ", "overly quiet ", "outside reality ", "our side ", "off topic ", "oh you ", "over ", "one word ", "one exception ",
		"outside itself ", "one zero ", "play acting ", "pretty bad ", "pretty cool ", "please do ", "preexisting ", "perfect ", "parental guidance ",
		"please help ", "personal information ", "proper job ", "personal knowledge ", "please ", "pay me ", "paranormal ", "preordained ",
		"pretty please ", "prequalified ", "public relations ", "possibly so ", "part time ", "pick up ", "point of view ", "planning works ", "perfect example ","player ",
		"player zero ", "quality assurance ", "quite boring ", "quite cool ", "quick draw ", "quite entertaining ", "quite fabulous ", "quite good ", "quite happy ", "quite impressive ",
		"quite jealous ", "quickly ", "qualified ", "quick movement ", "quiet now ", "quite obvious ", "quite pleasant ", "quick question ", "quite right",
		"quite similar", "quite telling ", "quite useful ", "quite valuable ", "quite wrong ", "exquisite ", "quiet yourself ", "quantize ", "right again ",
		"really bad ", "really cool ", "really depends ", "really easy ", "really funny ", "really good ", "really hard ", "real issue ",
		"really jealous ", "real kind", "really long ", "really minimal ", "right now ", "really old ", "role play ", "real quick ", "response requested ",
		"really short ", "realtime ", "really useful ", "reverse", "rewind ", "relax ", "really young ", "return zero ", "say again ",
		"stay back ", "stay close ", "stay down ", "sad excuse ", "stay fresh ", "heavy sigh ", "say hello ", "stay inside ", "same job ", "same kind ", "stay longer ",
		"save me ", "say nothing ", "stay outside ", "say please ", "stay quiet ", "so real ", "stay safe ", "same thing", "stay up ", "same variation ",
		"something will ", "same exact thing ", "see you ", "same zero ", "think about it ", "thats better ", "take care ", "that depends ", "try everything ",
		"too far ", "too good ", "try harder ", "try it ", "too jealous ", "too kind ", "try less ", "try me ", "try now ",
		"take over ", "take pleasure ", "try quieter ", "try reasoning", "too slow ", "try that ", "too useful ", "televisual ",
		"that works ", "thanks ", "thank you ", "trivialize ", "you agree ", "you bet ", "you can ", "you do ",
		"you explain ", "you forgot ", "you guess ", "you have ", "you insist ", "youre jealous ", "you know ", "your loss ",
		"you might ", "you next ", "you own ", "you pick ", "your question? ", "your response? ", "your show", "you too ",
		"youre useful ", "your vision ", "you will? ", "your explanation? ", "yes ", "your zero ", "very angry ", "very badly ",
		"very cheaply ", "very deeply ", "very evenly ", "very freely ", "very gross ", "very hot ", "very intelligent ", "very jumpy ",
		"very knowable ", "very limited ", "very material ", "very noticeable ", "very open ", "very picturesque ", "very quickly ",
		"very realistic ", "very simple ", "very tasteful ", "very unique ", "very visible ", "very wide ", "very exact ", "very everything", "view zero ",
		"we act ", "we begin ", "we collect ", "we decide ", "we explain ", "we forgot ", "we generate ", "we hope ", "we insist ", "worst job ever ",
		"we know ", "we lose ", "we must ", "work now ", "we observe ", "we play ", "we quit ", "we read ", "we show up ", "with that ",
		"with us ", "wider view ", "worldwide ", "we expect ", "we align ", "wisdom ", "extra awesome ", "exabytes ", "exciting ",
		"excited ", "exception ", "x factor ", "extinguish ", "exhaust ", "exit ", "extra jealous ", "extra knowledge ",
		"extra life ", "examine ", "extension ", "exoplanetary ", "explain ", "extra qualified ", "xray ", "extra space ",
		"extra time ", "extra universal ", "excessive ", "extra work", "explicit ", "explain yourself ", "extra zero", "your age ",
		"your body ", "your choice ", "your deal ", "your education ", "you forgot ", "your game ", "your house ", "your idea ", "your job ",
		"your kind ", "your loss ", "your mind ", "your needs ", "your own ", "your people ", "your question ", "your response ",
		"your safety ", "yours truly ", "your universe ", "your view ", "your world ", "your expectations ", "yes you ", "your zero ",
		"A", "B", "C ", "D ", "E ", "F",
		"G ", "H ", "I ", "J", "K", "L",
		"M", "N ", "O ", "P", "Q ", "R", "S",
	"T ", "U", "V ", "W", "X", "Y ", "Z " };
	
	@Override
	public IBinder onBind(Intent intent) {
	    return null;
	}
	public int odds = 1;
	private void synthpulse() {
		if (secureRandom.nextInt(256) < odds) {
			odds = 26;
			// Generate a random index within the range of the vocabulary array
			int randomIndex = secureRandom.nextInt(vocabulary.length);
			// Select the random string from the vocabulary array
			String word = vocabulary[randomIndex];
			mTTS.setPitch(((float)secureRandom.nextInt(10) / 15f) + 0.40f);
			mTTS.setSpeechRate(((float)secureRandom.nextInt(10) / 15f) + 0.65f);
			
			mTTS.speak(word, TextToSpeech.QUEUE_FLUSH, null, word);
		}
		odds -= 1;
		if(odds==0)odds=1;	
	}
	
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		mInstance = this;
		secureRandom = new SecureRandom();
		secureRandom.setSeed(System.currentTimeMillis());
		mTTS = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
			@Override
			public void onInit(int status) {
				timer = new Timer();
				task = new TimerTask() {
					public void run() {
						synthpulse();
					}
				};
				timer.scheduleAtFixedRate(task, 0, 100);
				
			}
			
		}); Toast.makeText(this, "Click me!", Toast.LENGTH_SHORT).show(); //onCreate called
		
	return START_STICKY;
	}
	private static PPPService mInstance= null;
	public static synchronized PPPService getInstance() {
        
        return mInstance;
    }
}
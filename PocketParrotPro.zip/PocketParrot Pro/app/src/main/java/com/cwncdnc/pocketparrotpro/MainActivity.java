package com.cwncdnc.pocketparrotpro;

import android.app.Service;
import android.content.Intent;
import android.system.Os;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;
import com.cwncdnc.pocketparrotpro.R;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;
import android.speech.tts.TextToSpeech;
import android.speech.tts.TextToSpeech.OnInitListener;
import java.util.Arrays;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.security.SecureRandom;
import java.util.Random;
import java.lang.Math;
import java.time.LocalTime;
import java.time.Clock;
import java.time.Instant;
import android.content.Context;

public class MainActivity extends Activity {
	
	
	Float[][] lweights = {
		//A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
		{ 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 255f, 2f, 2f, 2f,
		2f }, //A
		{ 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //B
		{ 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //C
		{ 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //D
		{ 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f,
		2f }, //E
		{ 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f,
		2f }, //F
		{ 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //G
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //H
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //I
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //J
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //K
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		255f }, //L
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //M
		{ 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //N
		{ 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //O
		{ 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //P
		{ 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //Q
		{ 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //R
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //S
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f,
		2f }, //T
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f,
		2f }, //U
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 255f, 2f, 2f, 2f,
		2f }, //V
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f,
		2f }, //W
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f,
		2f }, //X
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f,
		2f }, //Y
		{ 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
	255f } };//Z
	Float[][] rweights = {
		//A B C D E F G H I J K L M N O P Q R S T U V W X Y Z
		{ 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 255f, 2f, 2f, 2f,
		2f }, //A
		{ 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //B
		{ 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //C
		{ 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //D
		{ 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f,
		2f }, //E
		{ 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f,
		2f }, //F
		{ 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //G
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //H
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //I
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //J
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //K
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		255f }, //L
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //M
		{ 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //N
		{ 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //O
		{ 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //P
		{ 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //Q
		{ 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //R
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f, 2f,
		2f }, //S
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f,
		2f }, //T
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 2f, 2f, 2f, 2f,
		2f }, //U
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 255f, 255f, 2f, 2f, 2f,
		2f }, //V
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 255f, 2f, 2f,
		2f }, //W
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 255f, 2f,
		2f }, //X
		{ 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 255f,
		2f }, //Y
		{ 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 2f, 255f, 2f, 2f, 2f, 2f, 2f,
	255f } };//Z
	
	SecureRandom secureRandom;
	
	
	private void lcycle(Integer input) {
		Integer selected = 20;
		Integer count = 137;
		while (count > 0) { //AFTER DIMENSIONAL SUBSTITUTION IS EXHAUSTED, RECOLLECTION HAPPENS
			Integer next = 23;//SELECT THE HEAVIEST RETURN PATH.
			for (Integer check = 0; check < 26; check++) { //CHECK EACH EXIT:
				if (lweights[check][selected] / 2.3f > lweights[selected][check]) { //WHEN RETURN IS HEAVIER THAN EXIT,
					if (lweights[check][selected] * 2.3f <= 255)//WHEN LOADING IS NONDESTRUCTIVE,
					lweights[selected][check] *= 2.3f;
				} //LOAD EXITS TO HEAVY RETURNS.
				else if (lweights[selected][check] / 1.14f >= 2)
				lweights[selected][check] /= 1.14f; //NONDESTRUCTIVELY UNLOAD LIGHT RETURNS.
				if (lweights[check][selected] > lweights[next][selected])
				next = check; //NEXT PATH IS HEAVIEST RETURN.
			} //AFTER ALL PATHS ARE CHECKED,
			if (lweights[selected][input] < 250f)
			lweights[selected][input] += 4f; //SHE STORES OBSERVATION AS PROXIMITY.
			if (lweights[selected][input] >= 2.3f)
			lweights[selected][input] -= 1f; //SHE STORES TIME AS SPACE.
			selected = next; //SHE FOLLOWS THE PATH WITH THE HEAVIEST RETURN.
			count--; //SHE EXPERIENCES RECOLLECTION AFTER EXHAUSTING SUBSTITUTED DIMENSIONS.
		}
	};
	
	private void rcycle(Integer input) {
		Integer selected = 20;
		Integer count = 137;
		while (count > 0) { //AFTER DIMENSIONAL SUBSTITUTION IS EXHAUSTED, RECOLLECTION HAPPENS
			Integer next = 23;//SELECT THE HEAVIEST RETURN PATH.
			for (Integer check = 0; check < 26; check++) { //CHECK EACH EXIT:
				if (rweights[check][selected] / 2.3f > rweights[selected][check]) { //WHEN RETURN IS HEAVIER THAN EXIT,
					if (rweights[check][selected] * 2.3f <= 255)//WHEN LOADING IS NONDESTRUCTIVE,
					rweights[selected][check] *= 2.3f;
				} //LOAD EXITS TO HEAVY RETURNS.
				else if (rweights[selected][check] / 3.14f >= 2)
				rweights[selected][check] /= 3.14f; //NONDESTRUCTIVELY UNLOAD LIGHT RETURNS.
				if (rweights[check][selected] > rweights[next][selected])
				next = check; //NEXT PATH IS HEAVIEST RETURN.
			} //AFTER ALL PATHS ARE CHECKED,
			if (rweights[selected][input] < 250f)
			rweights[selected][input] += 4f; //SHE STORES OBSERVATION AS PROXIMITY.
			if (rweights[selected][input] >= 2.3f)
			rweights[selected][input] -= 1f; //SHE STORES TIME AS SPACE.
			selected = next; //SHE FOLLOWS THE PATH WITH THE HEAVIEST RETURN.
			count--; //SHE EXPERIENCES RECOLLECTION AFTER EXHAUSTING SUBSTITUTED DIMENSIONS.
		}
	};
	
	private Canvas mCanvas;
	private Paint mPaint;
	private Bitmap mBitmap;
	private ImageView mImageView;
	private Rect mRect;
	private Rect mBounds;
	private static final int OFFSET = 0;
	private int mOffset = OFFSET;
	private int mColorBackground;
	private int mColorRectangle;
	private int mColorAccent;
	
	Timer dtimer;
	TimerTask dtask;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		secureRandom = new SecureRandom();
		secureRandom.setSeed(System.currentTimeMillis());
		
		mPaint = new Paint();
		mRect = new Rect();
		mBounds = new Rect();
		mColorBackground = R.color.black;
		mColorRectangle = R.color.white;
		mColorAccent = R.color.black;
		mPaint.setColor(R.color.black);
		mImageView = (ImageView) findViewById(R.id.imgview);
		
	}
	
	@Override
	protected void onStart(){
		super.onStart();
		Toast.makeText(this, "Turn up your volume!!!", Toast.LENGTH_SHORT).show();
		Handler handler = new Handler();
		handler.postDelayed(new Runnable() {
			@Override
			public void run() {
				drawSomething(mImageView);
			}
		}, 1000);
		startService(new Intent(getBaseContext(), PPPService.class));
	}
	public void drawme(View view) {
		lcycle(secureRandom.nextInt(52) % 26);
		rcycle(secureRandom.nextInt(52) % 26);
					
		float vWidth = view.getWidth();
		float vHeight = view.getHeight();
		float vcx = vWidth / 26;
		float vcy = vHeight / 52;
		
		for (int ix = 0; ix < 26; ix++) {
			float xl = ix * vcx;
			for (int iy = 0; iy < 26; iy++) {
				float yt = iy * vcy;
				int amt = lweights[iy][ix].intValue();
				mPaint.setARGB(255, amt*iy, amt*ix , amt*iy*ix/26);
				mCanvas.drawRect(xl, yt, xl + vcx, yt + vcy, mPaint);
			}
		}
		for (int ix = 0; ix < 26; ix++) {
			float xl = ix * vcx;
			for (int iy = 0; iy < 26; iy++) {
				float yt = iy * vcy;
				int amt = rweights[iy][ix].intValue();
				mPaint.setARGB(255, amt*10, amt*10, amt*10);
				mCanvas.drawRect(xl, yt + vHeight / 2, xl + vcx, yt + vcy + vHeight / 2, mPaint);
				
			}
		}
	}
	
	public void drawSomething(View view) {
		
		int vWidth = mImageView.getWidth();
		int vHeight = mImageView.getHeight();
		mBitmap = Bitmap.createBitmap(vWidth, vHeight, Bitmap.Config.ARGB_8888);
		mImageView.setImageBitmap(mBitmap);
		mCanvas = new Canvas(mBitmap);
		if(dtimer!=null)dtimer.cancel();
		dtimer = new Timer();
		if(dtask!=null)dtask.cancel();
		dtask = new TimerTask() {
			public void run() {
				drawme(mImageView);
				mImageView.draw(mCanvas);
				mImageView.invalidate();
			}
		};
		dtimer.scheduleAtFixedRate(dtask, 0, 81);
		PPPService.getInstance().odds = 26;
		
	}
	
}